package com.telusko.demo.entities.repository;

import java.util.List;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.telusko.demo.entities.Employe;

public interface EmployeRepository extends JpaRepository<Employe, Integer>
{
//pagination
	@Query("from Employe as c where c.user.idUser =:idUser")
	//currentPage-Page
	//Contact Per Page - 5
	public Page<Employe> findEmployeByUser(@Param("idUser") int idUser, Pageable pageable);
	
}
