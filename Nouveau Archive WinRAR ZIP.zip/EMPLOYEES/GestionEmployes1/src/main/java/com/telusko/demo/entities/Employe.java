package com.telusko.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="EMPLOYE")
public class Employe
{@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int IdEmpl;
private String nom;
private String email;
private int contact;
private String poste;
@Column(length=500)
private String description;
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
private String image;

@ManyToOne
private User user;

public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public int getIdEmpl() {
	return IdEmpl;
}
public void setIdEmpl(int idEmpl) {
	this.IdEmpl = idEmpl;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}



public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public int getContact() {
	return contact;
}
public void setContact(int contact) {
	this.contact = contact;
}
public String getPoste() {
	return poste;
}
public void setPoste(String poste) {
	this.poste = poste;
}

public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
@Override
public String toString() {
	return "Employe [IdEmpl=" + IdEmpl + ", nom=" + nom + ",  email=" + email + ", contact="
			+ contact + ", poste=" + poste + ", description=" + description + ", image=" + image + ", user=" + user
			+ "]";
}


}
