package com.telusko.demo.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.telusko.demo.entities.Employe;
import com.telusko.demo.entities.User;
import com.telusko.demo.entities.repository.EmployeRepository;
import com.telusko.demo.entities.repository.UserRepository;
import com.telusko.demo.hhelper.Message;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private EmployeRepository employeRepository;

	@Autowired
	private UserRepository userRepository;

//method for adding employee
	@ModelAttribute
	public void addCommonData(Model m, Principal principal) {
		String userName = principal.getName();
		System.out.println("USERNAME " + userName);

		User user = userRepository.getUserByUserName(userName);
		m.addAttribute("user", user);

	}
	// dashboard home

	@RequestMapping("/index")

	public String dashboard(Model model, Principal principal) {

		model.addAttribute("title", "User Dashboard");
//get the user with his email
		return "normal/user_dash";
	}

	// open add form hadler
	@GetMapping("/add-employee")
	public String openAddContactForm(Model model) {
		model.addAttribute("title", "Add Employee");
		model.addAttribute("employee", new Employe());
		return "normal/add_employee_form";
	}
	// procession add employee form

	@PostMapping("/process-employee")
	public String processContact(@ModelAttribute Employe employee, @RequestParam("Profileimage") MultipartFile file,
			Principal principal, HttpSession session) {
		try {

			String nom = principal.getName();
			User user = this.userRepository.getUserByUserName(nom);

			// processiong and uploading file..
			if (file.isEmpty()) {
				// if the file is emplty then try our message
				System.out.println("File is empty");
				employee.setImage("contact.png");
			} else {
				// file the file to folder and update the name to employee
				employee.setImage(file.getOriginalFilename());
				File savefile = new ClassPathResource("static/img").getFile();
				Path path = Paths.get(savefile.getAbsolutePath() + File.separator + file.getOriginalFilename());
				Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
				System.out.println("Image is uploaded");
			}
			employee.setUser(user);
			user.getEmployes().add(employee);
			this.userRepository.save(user);

			System.out.println("DATA " + employee);
			System.out.println("Added to data base");

			// message success.........
			session.setAttribute("message", new Message("Your employee is added, add more... !!", "success"));
		} catch (Exception e) {
			System.out.println("ERROR " + e.getMessage());
			e.printStackTrace();
			// messageee erreur
			session.setAttribute("message", new Message("Some went wrong!! Try again ..", "danger"));

		}
		return "normal/add_employee_form";

	}
	// voir les employés
	// per page 5[n}

	// voir les employés
	@GetMapping("/show-employees/{page}")
	public String showEmployees(@PathVariable("page") Integer page, Model m, Principal principal) {
		m.addAttribute("title", "Show User Employees");
		// employees list
		String userName = principal.getName();
		User user = this.userRepository.getUserByUserName(userName);
		// currentPage-page
		Pageable pageable = PageRequest.of(page, 5);
		Page<Employe> employes = this.employeRepository.findEmployeByUser(user.getIdUser(), pageable);

		m.addAttribute("employees", employes);
		m.addAttribute("currentPage", page);

		m.addAttribute("totalPages", employes.getTotalPages());
		return "normal/show_employees";

	}

	// showing particular contact details
	@RequestMapping("/{IdEmpl}/employee")
	public String showContactDetail(@PathVariable("IdEmpl") Integer IdEmpl, Model model, Principal principal)

	{
		System.out.println("IdEmpl " + IdEmpl);

		Optional<Employe> employeOptional = this.employeRepository.findById(IdEmpl);

		Employe employee = employeOptional.get();

		//
		String userName = principal.getName();
		User user = this.userRepository.getUserByUserName(userName);
		if (user.getIdUser() == employee.getUser().getIdUser())

			model.addAttribute("employe", employee);
		model.addAttribute("title", employee.getNom());

		return "normal/employee_detail";
	}

	// delete employee
	@GetMapping("/delete/{IdEmpl}")
	public String deleteEmployee(@PathVariable("IdEmpl") Integer IdEmpl, Model model, HttpSession session)

	{
		System.out.println("IdEmployee " + IdEmpl);
		Employe employee = this.employeRepository.findById(IdEmpl).get();
		// check ..
		System.out.println("Employee " + employee.getIdEmpl());
		employee.setUser(null);
		
		//REMOVE IMG
		//employee.getImage()
		
		this.employeRepository.delete(employee);
		session.setAttribute("message", new Message("Employee deleted succesfully ...", "success"));

		return "redirect:/user/show-employees/0";
	}
	
	
	
	//open update
	
	@RequestMapping(value = "/update-employee/{IdEmpl}", method = { RequestMethod.GET, RequestMethod.POST })

	public String updateForm(@PathVariable("IdEmpl") Integer IdEmpl,Model m)
	{
		
	     m.addAttribute("title","Update Employee");
	     
	  Employe employee=   this.employeRepository.findById(IdEmpl).get();
	  
	  m.addAttribute("employe",employee);
	  
		 return "normal/update_form";
	}

}
