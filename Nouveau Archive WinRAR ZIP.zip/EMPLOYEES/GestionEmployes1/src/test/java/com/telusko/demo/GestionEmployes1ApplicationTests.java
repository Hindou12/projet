package com.telusko.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionEmployes1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
